import os
def reader(x):
    f = open(x, "r")
    txt = f.read()
    return txt
def write(x, txt):
    f = open(x, "w")
    f.write(str(txt))
    f.close()
    return
write("editors_list.txt",'')
u = input("what is your OVPN ID?")
p = input("what is your OVPN PASSWORD?")
directory =  str(os.getcwd()).replace('\\','/')+'/'
arr = os.listdir(directory)
num = int(len(arr))
i = int(0)
all_names = ''
while i < num:
    new = str(arr[i])
    if new[-5:] == ".ovpn":
        txt = reader(str(new))
        txt = txt.replace('auth.txt','').replace(' auth.txt','').replace('auth.txt','').replace(' auth.txt','').replace('auth.txt','')
        txt = txt.replace('auth-user-pass','auth-user-pass auth.txt')

        all_names = all_names +'"'+str(new)+'",'
        i = i + 1
        print("foundone")
    else:
        i = i + 1
all_names = all_names+','
all_names = all_names.replace(',,','')
write("editors_list.txt",all_names)

n = '\n'

auth = u + n + p
write('auth.txt', auth)
print('done')
